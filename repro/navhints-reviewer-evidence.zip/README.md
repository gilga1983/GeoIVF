# NavHints reviewer evidence

This public archive contains 48 aggregate JSON outputs from 35 original
experiment archives. Every aggregate is covered by MANIFEST.json; original
archive checksums and source provenance are retained. Raw datasets, query
vectors, graph indexes, per-request profiler CSVs, host diagnostics and
third-party source trees are excluded.

From a public GeoIVF checkout, run:

    python3 repro/run.py review --bundle repro/navhints-reviewer-evidence.zip
    python3 repro/export_paper_results.py --output artifacts/paper

The first command verifies the aggregate bytes and numeric contracts. The
second regenerates plot data and prepares a standalone figure/table sheet.
Neither command reruns the SSD measurements. Full replay instructions are in
docs/REPRODUCIBILITY.md and require the original authorized input data.

The Table 5 studies deliberately hold 16K junctions and one extra start fixed;
they isolate destination-source quality and history capacity. They are not
the selected 14,464-junction/2,048-history/eight-start headline configuration.

Use and redistribution terms are in the code repository's LICENSE. Upstream
engine and dataset terms remain separate. The public record includes only
the aggregate measurements used to review the paper; it grants no rights to
the omitted data or third-party software.
